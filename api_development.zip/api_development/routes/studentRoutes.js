const express = require("express");
const router = express.Router();

const {
    getAllStudents,
    getStudentById,
    createStudent,
    updateStudent,
    deleteStudent
} = require("../controllers/studentController");

// GET all students
router.get("/retrieve", getAllStudents);

// GET student by ID
router.get("/retrieve/:id", getStudentById);

// CREATE student
router.post("/register", createStudent);

// UPDATE student
router.put("/update/:id", updateStudent);

// DELETE student
router.delete("/delete/:id", deleteStudent);

module.exports = router;