
const { db } = require("../config/db");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

// =======================================
// REGISTER USER
// =======================================
const registerUser = async (req, res) => {
    try {
        const { userName, password, confirmPassword, role } = req.body;

        // Validate required fields
        if (!userName?.trim() || !password || !confirmPassword || !role) {
            return res.status(400).json({
                success: false,
                message: "All fields are required"
            });
        }

        // Validate username length
        if (userName.trim().length > 100) {
            return res.status(400).json({
                success: false,
                message: "Username cannot exceed 100 characters"
            });
        }

        // Validate role
        const allowedRoles = ["Admin", "Teacher", "Student"];

        if (!allowedRoles.includes(role)) {
            return res.status(400).json({
                success: false,
                message: "Invalid role. Allowed roles: Admin, Teacher, Student"
            });
        }

        // Validate password
        if (password.length < 8) {
            return res.status(400).json({
                success: false,
                message: "Password must contain at least 8 characters"
            });
        }

        if (password !== confirmPassword) {
            return res.status(400).json({
                success: false,
                message: "Passwords do not match"
            });
        }

        // Check existing username
        const [existingUser] = await db.query(
            "SELECT userId FROM `user` WHERE userName = ?",
            [userName.trim()]
        );

        if (existingUser.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Username already exists"
            });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 12);

        // Insert user with selected role
        const [result] = await db.query(
            `INSERT INTO \`user\` (userName, password, role)
             VALUES (?, ?, ?)`,
            [userName.trim(), hashedPassword, role]
        );

        return res.status(201).json({
            success: true,
            message: "User registered successfully",
            data: {
                userId: result.insertId,
                userName: userName.trim(),
                role: role
            }
        });

    } catch (error) {
        console.error("Registration error:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "Username already exists"
            });
        }

        return res.status(500).json({
            success: false,
            message: "Failed to register user"
        });
    }
};


// =======================================
// LOGIN USER
// =======================================
const loginUser = async (req, res) => {
    try {
        const { userName, password } = req.body;

        if (!userName?.trim() || !password) {
            return res.status(400).json({
                success: false,
                message: "Username and password are required"
            });
        }

        // Find user
        const [users] = await db.query(
            `SELECT userId, userName, password, role
             FROM \`user\`
             WHERE userName = ?
             LIMIT 1`,
            [userName.trim()]
        );

        if (users.length === 0) {
            return res.status(401).json({
                success: false,
                message: "Invalid username or password"
            });
        }

        const user = users[0];

        // Verify password
        const passwordMatch = await bcrypt.compare(
            password,
            user.password
        );

        if (!passwordMatch) {
            return res.status(401).json({
                success: false,
                message: "Invalid username or password"
            });
        }

        // Generate JWT
        const token = jwt.sign(
            {
                userId: user.userId,
                userName: user.userName,
                role: user.role
            },
            process.env.JWT_SECRET,
            {
                expiresIn: process.env.JWT_EXPIRES_IN || "1d"
            }
        );

        return res.status(200).json({
            success: true,
            message: "Login successful",
            token,
            data: {
                userId: user.userId,
                userName: user.userName,
                role: user.role
            }
        });

    } catch (error) {
        console.error("Login error:", error);

        return res.status(500).json({
            success: false,
            message: "Login failed"
        });
    }
};


// =======================================
// EXPORT CONTROLLERS
// =======================================
module.exports = {
    registerUser,
    loginUser
};
