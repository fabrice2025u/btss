
const { db } = require("../config/db");

// =====================================
// GET ALL STUDENTS
// =====================================
const getAllStudents = async (req, res) => {
    try {
        const [students] = await db.query(
            `SELECT studentID, firstName, lastName, gender,
                    dateOfBirth, class, phoneNumber, email
             FROM students
             ORDER BY studentID DESC`
        );

        return res.status(200).json({
            success: true,
            count: students.length,
            data: students
        });

    } catch (error) {
        console.error("Get students error:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to retrieve students"
        });
    }
};


// =====================================
// GET STUDENT BY ID
// =====================================
const getStudentById = async (req, res) => {
    try {
        const { id } = req.params;

        if (!Number.isInteger(Number(id)) || Number(id) < 1) {
            return res.status(400).json({
                success: false,
                message: "Invalid student ID"
            });
        }

        const [students] = await db.query(
            "SELECT * FROM students WHERE studentID = ?",
            [id]
        );

        if (students.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Student not found"
            });
        }

        return res.status(200).json({
            success: true,
            data: students[0]
        });

    } catch (error) {
        console.error("Get student error:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to retrieve student"
        });
    }
};


// =====================================
// CREATE STUDENT
// =====================================
const createStudent = async (req, res) => {
    try {
        const {
            firstName,
            lastName,
            gender,
            dateOfBirth,
            class: studentClass,
            phoneNumber,
            email
        } = req.body;

        // Validate required fields
        if (
            !firstName?.trim() ||
            !lastName?.trim() ||
            !gender ||
            !dateOfBirth ||
            !studentClass?.trim()
        ) {
            return res.status(400).json({
                success: false,
                message: "Please provide all required student fields"
            });
        }

        // Validate gender
        if (!["Male", "Female"].includes(gender)) {
            return res.status(400).json({
                success: false,
                message: "Gender must be Male or Female"
            });
        }

        // Validate date format and actual calendar date
        const datePattern = /^\d{4}-\d{2}-\d{2}$/;
        const parsedDate = new Date(`${dateOfBirth}T00:00:00.000Z`);

        if (
            typeof dateOfBirth !== "string" ||
            !datePattern.test(dateOfBirth) ||
            Number.isNaN(parsedDate.getTime()) ||
            parsedDate.toISOString().slice(0, 10) !== dateOfBirth
        ) {
            return res.status(400).json({
                success: false,
                message: "Date of birth must be a valid YYYY-MM-DD date"
            });
        }

        // Validate email if provided
        const studentEmail = email?.trim() || null;

        if (
            studentEmail &&
            !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(studentEmail)
        ) {
            return res.status(400).json({
                success: false,
                message: "Please provide a valid email address"
            });
        }

        const [result] = await db.query(
            `INSERT INTO students
            (firstName, lastName, gender, dateOfBirth,
             class, phoneNumber, email)
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                firstName.trim(),
                lastName.trim(),
                gender,
                dateOfBirth,
                studentClass.trim(),
                phoneNumber?.trim() || null,
                studentEmail
            ]
        );

        return res.status(201).json({
            success: true,
            message: "Student registered successfully",
            data: {
                studentID: result.insertId,
                firstName: firstName.trim(),
                lastName: lastName.trim(),
                gender,
                dateOfBirth,
                class: studentClass.trim(),
                phoneNumber: phoneNumber?.trim() || null,
                email: studentEmail
            }
        });

    } catch (error) {
        console.error("Create student error:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "This email address is already registered"
            });
        }

        return res.status(500).json({
            success: false,
            message: "Failed to register student"
        });
    }
};


// =====================================
// UPDATE STUDENT
// =====================================
const updateStudent = async (req, res) => {
    try {
        const { id } = req.params;

        if (!Number.isInteger(Number(id)) || Number(id) < 1) {
            return res.status(400).json({
                success: false,
                message: "Invalid student ID"
            });
        }

        const {
            firstName,
            lastName,
            gender,
            dateOfBirth,
            class: studentClass,
            phoneNumber,
            email
        } = req.body;

        if (
            !firstName?.trim() ||
            !lastName?.trim() ||
            !gender ||
            !dateOfBirth ||
            !studentClass?.trim()
        ) {
            return res.status(400).json({
                success: false,
                message: "All required student fields must be provided"
            });
        }

        if (!["Male", "Female"].includes(gender)) {
            return res.status(400).json({
                success: false,
                message: "Gender must be Male or Female"
            });
        }

        const datePattern = /^\d{4}-\d{2}-\d{2}$/;
        const parsedDate = new Date(`${dateOfBirth}T00:00:00.000Z`);

        if (
            typeof dateOfBirth !== "string" ||
            !datePattern.test(dateOfBirth) ||
            Number.isNaN(parsedDate.getTime()) ||
            parsedDate.toISOString().slice(0, 10) !== dateOfBirth
        ) {
            return res.status(400).json({
                success: false,
                message: "Please provide a valid date of birth"
            });
        }

        const studentEmail = email?.trim() || null;

        if (
            studentEmail &&
            !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(studentEmail)
        ) {
            return res.status(400).json({
                success: false,
                message: "Please provide a valid email address"
            });
        }

        const [result] = await db.query(
            `UPDATE students
             SET firstName = ?,
                 lastName = ?,
                 gender = ?,
                 dateOfBirth = ?,
                 class = ?,
                 phoneNumber = ?,
                 email = ?
             WHERE studentID = ?`,
            [
                firstName.trim(),
                lastName.trim(),
                gender,
                dateOfBirth,
                studentClass.trim(),
                phoneNumber?.trim() || null,
                studentEmail,
                id
            ]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Student not found"
            });
        }

        return res.status(200).json({
            success: true,
            message: "Student updated successfully"
        });

    } catch (error) {
        console.error("Update student error:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "This email address is already used by another student"
            });
        }

        return res.status(500).json({
            success: false,
            message: "Failed to update student"
        });
    }
};


// =====================================
// DELETE STUDENT
// =====================================
const deleteStudent = async (req, res) => {
    try {
        const { id } = req.params;

        if (!Number.isInteger(Number(id)) || Number(id) < 1) {
            return res.status(400).json({
                success: false,
                message: "Invalid student ID"
            });
        }

        const [result] = await db.query(
            "DELETE FROM students WHERE studentID = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Student not found"
            });
        }

        return res.status(200).json({
            success: true,
            message: "Student deleted successfully"
        });

    } catch (error) {
        console.error("Delete student error:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to delete student"
        });
    }
};


// =====================================
// EXPORT CONTROLLERS
// =====================================
module.exports = {
    getAllStudents,
    getStudentById,
    createStudent,
    updateStudent,
    deleteStudent
};
