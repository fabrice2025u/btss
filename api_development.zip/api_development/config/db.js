
const mysql = require("mysql2/promise");
require("dotenv").config();

// Create MySQL connection pool
const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,

    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,

    enableKeepAlive: true
});

// Test database connection
const connectDB = async () => {
    try {
        const connection = await db.getConnection();

        console.log("MySQL database connected successfully!");

        connection.release();

    } catch (error) {
        console.error("Database connection failed:", error.message);
        throw error;
    }
};

module.exports = {
    db,
    connectDB
};
