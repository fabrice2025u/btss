
require("dotenv").config();

const express = require("express");
const cors = require("cors");



const { connectDB } = require("./config/db");

// Initialize Express
const app = express();

const PORT = process.env.PORT || 5000;

// ===================================
// MIDDLEWARE CONFIGURATION
// ===================================

app.use(cors());

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

// ===================================
// API ROUTES
// ===================================

// API welcome route
app.get("/api", (req, res) => {
    res.status(200).json({
        success: true,
        message: "Welcome to Student Management RESTful API",
        version: "1.0.0"
    });
});


const studentRoutes = require("./routes/studentRoutes");

app.use("/api/students", studentRoutes);

const userRoutes = require("./routes/userRoutes");

app.use("/api/users", userRoutes);
// Student routes
// app.use("/api/students", require("./routes/studentRoutes"));

// User routes
// app.use("/api/users", require("./routes/userRoutes"));

// ===================================
// 404 HANDLER
// ===================================

app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: "API endpoint not found",
        path: req.originalUrl
    });
});

// ===================================
// GLOBAL ERROR HANDLER
// ===================================

app.use((err, req, res, next) => {
    console.error("API Error:", err.message);

    res.status(err.status || 500).json({
        success: false,
        message: err.message || "Internal server error"
    });
});

// ===================================
// START SERVER
// ===================================

const startServer = async () => {
    try {
        // Connect to MySQL
        await connectDB();

        // Start Express server
        app.listen(PORT, () => {
            console.log("=================================");
            console.log("STUDENT MANAGEMENT REST API");
            console.log(`Server running on port ${PORT}`);
            console.log(`API URL: http://localhost:${PORT}/api`);
            console.log(`Environment: ${process.env.NODE_ENV}`);
            console.log("=================================");
        });

    } catch (error) {
        console.error("Server startup failed:", error.message);
        process.exit(1);
    }
};

startServer();
